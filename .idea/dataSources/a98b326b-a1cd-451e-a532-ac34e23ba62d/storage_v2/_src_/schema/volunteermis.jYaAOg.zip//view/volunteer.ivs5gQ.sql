create definer = root@localhost view volunteer as
(
select `volunteermis`.`student_base_info`.`sno`         AS `sno`,
       `volunteermis`.`student_base_info`.`name`        AS `name`,
       `volunteermis`.`student_base_info`.`sex`         AS `sex`,
       `volunteermis`.`student_base_info`.`grade`       AS `grade`,
       `volunteermis`.`student_base_info`.`major`       AS `major`,
       `volunteermis`.`student_base_info`.`semester`    AS `semester`,
       `volunteermis`.`student_base_info`.`phone`       AS `phone`,
       `volunteermis`.`volunteer_info`.`native_place`   AS `native_place`,
       `volunteermis`.`volunteer_info`.`dialect`        AS `dialect`,
       `volunteermis`.`volunteer_info`.`character`      AS `character`,
       `volunteermis`.`volunteer_info`.`speciality`     AS `speciality`,
       `volunteermis`.`volunteer_info`.`wechat`         AS `wechat`,
       `volunteermis`.`volunteer_info`.`QQ`             AS `qq`,
       `volunteermis`.`volunteer_info`.`drom`           AS `drom`,
       `volunteermis`.`volunteer_info`.`experience`     AS `experience`,
       `volunteermis`.`volunteer_info`.`vol_experience` AS `vol_experience`,
       `volunteermis`.`volunteer_info`.`others`         AS `others`
from `volunteermis`.`student_base_info`
         join `volunteermis`.`volunteer_info`
where (`volunteermis`.`student_base_info`.`sno` = `volunteermis`.`volunteer_info`.`sno`));

