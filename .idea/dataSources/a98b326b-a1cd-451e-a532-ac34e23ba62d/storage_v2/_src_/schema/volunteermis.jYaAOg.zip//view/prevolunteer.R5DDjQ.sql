create definer = root@localhost view prevolunteer as
select `volunteermis`.`student_base_info`.`sno`        AS `sno`,
       `volunteermis`.`student_base_info`.`name`       AS `name`,
       `volunteermis`.`student_base_info`.`sex`        AS `sex`,
       `volunteermis`.`student_base_info`.`grade`      AS `grade`,
       `volunteermis`.`student_base_info`.`major`      AS `major`,
       `volunteermis`.`student_base_info`.`semester`   AS `semester`,
       `volunteermis`.`student_base_info`.`phone`      AS `phone`,
       `volunteermis`.`prevolunteer_info`.`dialect`    AS `dialect`,
       `volunteermis`.`prevolunteer_info`.`speciality` AS `speciality`,
       `volunteermis`.`prevolunteer_info`.`reason`     AS `reason`,
       `volunteermis`.`prevolunteer_info`.`experience` AS `experience`
from `volunteermis`.`prevolunteer_info`
         join `volunteermis`.`student_base_info`
where (`volunteermis`.`prevolunteer_info`.`sno` = `volunteermis`.`student_base_info`.`sno`);

